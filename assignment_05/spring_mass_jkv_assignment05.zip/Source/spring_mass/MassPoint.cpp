// Fill out your copyright notice in the Description page of Project Settings.

#include "MassPoint.h"
#include "spring_mass.h"


MassPoint::MassPoint(uint32 vertex_id, bool movable, FVector pos)
    : m_vertex_id(vertex_id),
      m_currPos(pos),
      m_force(FVector::ZeroVector),
      m_velocity(FVector::ZeroVector),
      m_movable(movable),
      m_mass(5.0f)
{
    // 2) Initialize the oldPos to the same as the current position (so there's no jump at t=0).
    m_oldPos = m_currPos;
}


void MassPoint::updateGravity()
{
    // 1. Base gravity vector (typical Unreal scale)
    FVector baseGravity(0, 0, -980.f);

    // 2. If the mass point is fixed (not movable), skip gravity
    if (!m_movable)
    {
        return;
    }

    // 3. Generate a small random offset
    //    Let's randomize X and Z in some small range, say -5..+5
    float offsetX = FMath::FRandRange(-5.f, 5.f);
    float offsetZ = FMath::FRandRange(-5.f, 5.f);
    FVector randomOffset(offsetX, 0.0f, offsetZ);

    // 4. Combine them to form our "perturbed gravity"
    FVector finalGravity = baseGravity + randomOffset;

    // 5. Apply F = m*g, using this finalGravity
    m_force += finalGravity * m_mass;
}



void MassPoint::updateCurPos(float deltaT)
{
    if (m_movable)
    {
        // 1) Compute acceleration = F / m
        FVector acceleration = m_force / m_mass;

        // 2) Verlet formula:
        //    newPos = currentPos + (currentPos - oldPos) + acceleration * dt^2
        FVector newPos = m_currPos
                         + (m_currPos - m_oldPos)
                         + acceleration * (deltaT * deltaT);

        // 3) Shift old position
        m_oldPos = m_currPos;

        // 4) Assign current position
        m_currPos = newPos;
    }

    // 5) Reset force each frame
    m_force = FVector::ZeroVector;
}


void
MassPoint::addForce(FVector f)
{
	if (m_movable)
	{
		m_force += f;
	}
}

MassPoint::~MassPoint()
{
}
