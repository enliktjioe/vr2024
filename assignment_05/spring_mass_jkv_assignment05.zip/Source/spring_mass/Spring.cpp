// Fill out your copyright notice in the Description page of Project Settings.

#include "Spring.h"
#include "spring_mass.h"

Spring::Spring(MassPoint* m1, MassPoint* m2, float length) :
m_m1(m1), m_m2(m2), 
m_spring_length_init(length),
m_stiffness(2.0f),
m_damper(0.01f)
{
}

Spring::~Spring()
{
}


void
Spring::Tick()
{
    // 1. Retrieve positions of the two mass points
    FVector pos1 = m_m1->m_currPos;
    FVector pos2 = m_m2->m_currPos;

    // 2. Compute the displacement vector (pos2 - pos1), its length, and direction
    FVector delta = pos2 - pos1;
    float currentLength = delta.Size();      // distance between points
    if (currentLength < KINDA_SMALL_NUMBER)
    {
        // To avoid divide-by-zero or numerical issues if the points coincide
        return;
    }
    FVector direction = delta / currentLength; // normalized direction from m1 to m2

    // 3. Compute extension or compression: (currentLength - restLength)
    float extension = currentLength - m_spring_length_init;

    // 4. Hooke's law: F_spring = -k * extension * direction
    FVector springForce = -m_stiffness * extension * direction;

    // 5. Damping force: F_damp = -c * (v1 - v2)
    //    We have direct access to m1->m_velocity, m2->m_velocity (because 'friend class Spring')
    FVector relVel = m_m1->m_velocity - m_m2->m_velocity;
    FVector dampingForce = -m_damper * relVel;

    // 6. Sum them
    FVector totalForce = springForce + dampingForce;

    // 7. Apply forces to mass points
    m_m1->addForce(totalForce);
    m_m2->addForce(-totalForce); // equal and opposite to the other point
}

